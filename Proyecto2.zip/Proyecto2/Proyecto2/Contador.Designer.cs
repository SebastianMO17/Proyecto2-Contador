﻿
namespace Proyecto2
{
    partial class Contador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Lblcont = new System.Windows.Forms.Label();
            this.btndis = new System.Windows.Forms.Button();
            this.btnrein = new System.Windows.Forms.Button();
            this.btnincre = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(261, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(348, 73);
            this.label1.TabIndex = 0;
            this.label1.Text = "COUNTER";
            // 
            // Lblcont
            // 
            this.Lblcont.AutoSize = true;
            this.Lblcont.BackColor = System.Drawing.Color.Transparent;
            this.Lblcont.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lblcont.ForeColor = System.Drawing.Color.Lime;
            this.Lblcont.Location = new System.Drawing.Point(394, 167);
            this.Lblcont.Name = "Lblcont";
            this.Lblcont.Size = new System.Drawing.Size(68, 73);
            this.Lblcont.TabIndex = 1;
            this.Lblcont.Text = "0";
            // 
            // btndis
            // 
            this.btndis.Location = new System.Drawing.Point(250, 310);
            this.btndis.Name = "btndis";
            this.btndis.Size = new System.Drawing.Size(91, 48);
            this.btndis.TabIndex = 2;
            this.btndis.Text = "Disminuir";
            this.btndis.UseVisualStyleBackColor = true;
            this.btndis.Click += new System.EventHandler(this.btndis_Click);
            // 
            // btnrein
            // 
            this.btnrein.Location = new System.Drawing.Point(386, 310);
            this.btnrein.Name = "btnrein";
            this.btnrein.Size = new System.Drawing.Size(94, 48);
            this.btnrein.TabIndex = 3;
            this.btnrein.Text = "Reiniciar";
            this.btnrein.UseVisualStyleBackColor = true;
            this.btnrein.Click += new System.EventHandler(this.btnrein_Click);
            // 
            // btnincre
            // 
            this.btnincre.Location = new System.Drawing.Point(526, 310);
            this.btnincre.Name = "btnincre";
            this.btnincre.Size = new System.Drawing.Size(99, 48);
            this.btnincre.TabIndex = 4;
            this.btnincre.Text = "Incrementar";
            this.btnincre.UseVisualStyleBackColor = true;
            this.btnincre.Click += new System.EventHandler(this.btnincre_Click);
            // 
            // Contador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnincre);
            this.Controls.Add(this.btnrein);
            this.Controls.Add(this.btndis);
            this.Controls.Add(this.Lblcont);
            this.Controls.Add(this.label1);
            this.Name = "Contador";
            this.Text = "Contador";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Lblcont;
        private System.Windows.Forms.Button btndis;
        private System.Windows.Forms.Button btnrein;
        private System.Windows.Forms.Button btnincre;
    }
}