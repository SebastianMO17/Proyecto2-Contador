﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto2
{
    public partial class Contador : Form
    {
        public Contador()
        {
            InitializeComponent();
        }
        int contador = 0;
        int vlr = 0;
        private void btnincre_Click(object sender, EventArgs e)
        {
            vlr =Convert.ToInt32(Lblcont.Text);
            contador = vlr;
            contador = contador + 1;
            Lblcont.Text =  contador.ToString();
            if(contador>0)
            {

                Lblcont.ForeColor = Color.Green;
            }
            else if (contador == 0)
            {
                Lblcont.ForeColor = Color.Orange;
            }
            else
            {
                Lblcont.ForeColor = Color.Red;
            }
        }

        private void btndis_Click(object sender, EventArgs e)
        {
            vlr = Convert.ToInt32(Lblcont.Text);
            contador = vlr;
            contador = contador - 1;
            Lblcont.Text = contador.ToString();
            if (contador > 0)
           
            {

                Lblcont.ForeColor = Color.Green;
            }
            else if (contador == 0)
            {
                Lblcont.ForeColor = Color.Orange;
            }
            else
            {
                Lblcont.ForeColor = Color.Red;
            }

        }

        private void btnrein_Click(object sender, EventArgs e)
        {
            Lblcont.Text = "0";
            Lblcont.ForeColor = Color.Blue;
        }
    }
}
