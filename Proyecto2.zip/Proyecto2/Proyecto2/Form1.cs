﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
      
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }

        private void btnMatrices_Click(object sender, EventArgs e)
        {
            int[,] valores = new int[2, 2];
            //Almacenar valores en la matriz
            valores[0, 0] = 100;
            valores[0, 1] = 50;
            valores[1, 0] = 60;
            valores[1,1] = 25;
            //insertar valores de matriz en listbox
            listBox1.Items.Add(valores[0, 0]);
            listBox1.Items.Add(valores[0, 1]);
            listBox1.Items.Add(valores[1, 0]);
            listBox1.Items.Add(valores[1, 1]);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[,] valores2 = new string[3, 2];
            valores2[0, 0] = "a";
            valores2[0, 1] = "1";
            valores2[1, 0] = "b";
            valores2 [1, 1] = "2";
            valores2[2, 0] = "c";
            valores2[2, 1] = "3";

            listBox2.Items.Add(valores2[0, 0]);
            listBox2.Items.Add(valores2[0, 1]);
            listBox2.Items.Add(valores2[1, 0]);
            listBox2.Items.Add(valores2[1, 1]);
            listBox2.Items.Add(valores2[2, 0]);
            listBox2.Items.Add(valores2[2, 1]);

        }
    }
}
